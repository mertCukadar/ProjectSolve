#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
class Demo {
    private:
        int counter;

    public:
        Demo(int counter);
        int checkNumbers(int x, int y);
};
