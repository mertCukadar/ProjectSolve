#include "Demo.h"
using namespace std;


int main(){
    Demo demo(5);
    Demo demo2(8);
    int a = demo.checkNumbers(13,222);
}

